from detect_mask.models import User, Student, MaskDetail
from django.utils.timezone import datetime
from django.db.models import Count

today = datetime.today()
queryset = (
                MaskDetail.objects.values("user_id")
                .filter(
                date_time__year=today.year,
                date_time__month=today.month,
                date_time__day=today.day,)
                .annotate(total=Count("mask_status"))
            )

for (i,d) in enumerate(queryset):
    print(i,d)
