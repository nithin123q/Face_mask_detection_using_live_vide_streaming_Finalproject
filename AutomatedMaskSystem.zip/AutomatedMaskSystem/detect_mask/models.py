from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import User,AbstractUser
from django.core.validators import RegexValidator
from django.utils import timezone
from django.db import models
# from django.db.models.signals import post_save
# from django.dispatch import receiver
# from django_celery_beat.models import MINUTES, PeriodicTask, CrontabSchedule, PeriodicTasks
# import json

class Department(models.Model):
    did = models.IntegerField(primary_key = True)
    dept_name = models.CharField(max_length = 50,blank = True)

    def __str__(self): 
        return str(self.dept_name)

class User(AbstractUser):
    pid = models.IntegerField(primary_key=True, unique=True, 
                validators = [RegexValidator(regex='^.{6}$', message='pid should be 6 digit')])
    email = models.EmailField(unique =True)
    first_name = models.CharField(max_length=50,blank = True)
    last_name = models.CharField(max_length=50,blank = True)
    
    def __str__(self): 
        return str(self.pk)


class Student(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE,primary_key=True)
    roll_no = models.CharField(max_length=10,blank = True)
    contact_no = models.IntegerField(blank = True,null=True,
                validators = [RegexValidator(regex='^.{10}$', message='Contact should be 6 digit')])
    violation_count = models.IntegerField(blank = True, null = True)
    dept = models.ForeignKey(Department,on_delete=models.CASCADE, null = True, blank = True)

    def __str__(self): 
        return str(self.violation_count) 


# Create one more table having name today_mask and create table with user table
# and then at the end of the day increase the violation count of student in studetn table
class MaskDetail(models.Model):
    mid = models.IntegerField(primary_key=True, unique=True)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    date_time = models.DateTimeField(default=timezone.now())
    mask_status = models.BooleanField(default=False)
    update_done = models.BooleanField(default=False)
    senr = models.BooleanField(default=False)

 
# @receiver(post_save, sender=MaskDetail)
# def notification_handler(sender, instance, created, **kwargs):
#     # call group_send function directly to send notificatoions or you can create a dynamic task in celery beat
#     if created:
#         schedule, created = CrontabSchedule.objects.get_or_create(hour = instance.date_time.hour, minute = date_time.date_time.minute, day_of_month = instance.date_time.day, month_of_year = instance.date_time.month)
#         task = PeriodicTask.objects.create(crontab=schedule, name="broadcast-notification-"+str(instance.id), task="notificationapp.tasks.broadcast_notification", args=json.dumps((instance.id,)))

#     #if not created:

