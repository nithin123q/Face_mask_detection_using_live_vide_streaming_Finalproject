from django.contrib import admin
from detect_mask.models import User, Student, MaskDetail, Department

class UserAdmin(admin.ModelAdmin):
    search_fields = ["username","email",]
    list_display = ["pk","first_name","last_name","email"]

class StudentAdmin(admin.ModelAdmin):
    search_fields = ["user","violation_count"]
    list_filter = ["roll_no",]
    list_display = ["user","roll_no","violation_count","contact_no"]

class MaskDetailAdmin(admin.ModelAdmin):
    search_fields = ["user","mask_status"]
    # dt = utc_dt.astimezone() # local time
    list_display = ["mid","user","update_done","mask_status","date_time"]

class DepartmentAdmin(admin.ModelAdmin):
    search_fields = ["did","dept_name"]
    list_display = ["did","dept_name"]

admin.site.register(Student,StudentAdmin)
admin.site.register(User,UserAdmin)
admin.site.register(MaskDetail,MaskDetailAdmin)
admin.site.register(Department,DepartmentAdmin)




















#user: yogita24   pass: pass*4567
#user: nithin11   pass: nithin*123
#user: sherwin11  pass: sherwin234
#user: ujala   pass: ujala191
#superuser: anchal pass:ujala19