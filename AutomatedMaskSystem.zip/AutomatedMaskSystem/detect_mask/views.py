from django.shortcuts import render,redirect
from django.http.response import StreamingHttpResponse
from django.http import HttpResponse
from django.template import RequestContext
from django.conf import settings
from tensorflow.keras.models import load_model
from imutils.video import VideoStream
from detect_mask.mask_detection import detect_and_predict_mask
from detect_mask.models import User, Student, MaskDetail, Department
import cv2
import imutils
import os
from django.contrib import messages
from detect_mask.PersonDetector import RecognizePerson
import time
from detect_mask.graphs import get_pie,get_plot,get_bar
from datetime import timedelta, date
from django.utils import timezone
from django.utils.timezone import datetime
from django.db.models import Count,Sum
from django.core.mail import send_mail
# from channels.layers import get_channel_layer
# from django.template import RequestContext
import json
from playsound import playsound
# address = "http://192.168.0.100:8080/video"

font = cv2.FONT_HERSHEY_SIMPLEX

prototxtPath = r"C:/Users/ujala/OneDrive/Documents/project/AutomatedMaskSystem/model/deploy.prototxt"

weightsPath = r"C:/Users/ujala/OneDrive/Documents/project/AutomatedMaskSystem/model/res10_300x300_ssd_iter_140000.caffemodel"

rp=RecognizePerson()

rp.encoded_images(r"C:\Users\ujala\OneDrive\Documents\project\AutomatedMaskSystem\images")

faceNet = cv2.dnn.readNet(prototxtPath, weightsPath)

maskNet = load_model(os.path.join(settings.BASE_DIR,'model/mask_detector.model'))


class WebCam(object):
    def __init__(self):
        # self.video = cv2.VideoCapture(0)
        # self.video.open(address)
        self.video = VideoStream(src=0).start()#this is for laptop camera

    def __del__(self):
        self.video.stop()
    
    def get_frame(self):
        frame = self.video.read()
        frame = imutils.resize(frame, width=500)

        (locs, preds) = detect_and_predict_mask(frame, faceNet, maskNet)

        for (box, pred) in zip(locs, preds):
            (startX, startY, endX, endY) = box
            (mask, withoutMask) = pred

            if mask > withoutMask:
                label="Mask"
                color = (0,255,0)
                cv2.putText(frame, label, (startX,startY-10), font, 0.7, color, 2)
                cv2.rectangle(frame,(startX,startY),(endX,endY), color, 2)
                
            else:
                color = (0,0,255)
                face=frame[startY:endY,startX:endX]
                (_,pids) = rp.detect_known_faces(face)
                for pid in pids:
                #     if pid == 'Unknown':
                #         continue
                    label="No Mask: " + pid
                    cv2.putText(frame, label, (startX,startY-10), font, 0.7, color, 2)
                    cv2.rectangle(frame, (startX,startY),(endX,endY), color, 2)

                    # Addding violation data into MaskDetail Table
                    if(pid == 'Unknown'):
                        continue
                    m = MaskDetail.objects.filter(user_id = pid)
                    if(m):
                        lasttime = m.last().date_time
                        lesstime = timezone.now() - timedelta(minutes=5)
                        if lasttime <= lesstime:
                            md = MaskDetail(mask_status = False, user_id = pid, date_time = timezone.now())
                            md.save()
                            playsound('C://Users/ujala/OneDrive/Documents/project/AutomatedMaskSystem/detect_mask/beep-09.mp3')
                    else:                        
                        md = MaskDetail(mask_status = False, user_id = pid)
                        md.save()
                                       

        ret, jpeg = cv2.imencode('.jpg', frame)
        return jpeg.tobytes() 


def main(request):
    return render(request,'detect_mask/main.html')

# from asgiref.sync import async_to_sync
# def test(request):
#     channel_layer = get_channel_layer()
#     async_to_sync(channel_layer.group_send)(
#         "notification_broadcast",
#         {
#             'type': 'send_notification',
#             'message': "notification"
#         }
#     )
#     return HttpResponse("Done")


def gen(camera):
	while True:
		frame = camera.get_frame()
		yield (b'--frame\r\n'
				b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')


def video_feed(request):
	return StreamingHttpResponse(gen(WebCam()),
					content_type='multipart/x-mixed-replace; boundary=frame')


def graph_details(request):
    # lastm = today.month - 1
    # last_month = (
    #                 MaskDetail.objects.filter(date_time__month = lastm)
    #                 .aggregate(Sum("mask_status"))
    #             )

    month_data = MaskDetail.objects.values("date_time__month").annotate(total=Sum("update_done"))

    dept_data = Student.objects.values("dept__dept_name").annotate(total=Sum("violation_count")).order_by("total").reverse()

    everyday_data = MaskDetail.objects.values("date_time__day","date_time__month").annotate(total=Sum("update_done")).order_by("date_time__month")

    return render(request,'detect_mask/graph.html',{'plot_chart':get_plot(everyday_data),'pie_chart':get_pie(month_data),'bar_chart':get_bar(dept_data)})
    
        
def display_details(request):
    today = datetime.today()
    queryset = (
                    MaskDetail.objects.values("user_id","update_done")
                    .filter(update_done = False)
                    .annotate(total=Count("mask_status"))
                )
    if(queryset is not None):
        for row in queryset:
            pid = row['user_id']
            user = User.objects.get(pid = pid)
            new_violation = row['total'] + user.student.violation_count
            Student.objects.filter(user_id = user).update(violation_count = new_violation)
            MaskDetail.objects.filter(user_id = user).update(update_done=1)
            user = User.objects.all()

    # ***************************************************************
    user = User.objects.all()
    user_query = (
                Student.objects.values("user__pid","user__email","user__first_name","user__last_name","dept__dept_name","violation_count")
                .order_by('violation_count').reverse()
    )

    # *****************************************************************

    today_details = []
    today_query = (
                    MaskDetail.objects.values("user_id")
                    .filter(date_time__day = today.day)
                    .annotate(total=Count("mask_status")).order_by('total').reverse()
                )
    for tr in today_query:
        d = {}
        d['total'] = tr['total']
        d['u'] = User.objects.get(pid = tr['user_id'])
        today_details.append(d)

    # ************************************************************************
    yesterday_details = []
    yesterday = today - timedelta(days = 1)
    yesterday_query = (
                    MaskDetail.objects.values("user_id")
                    .filter(date_time__day=yesterday.day)
                    .annotate(total=Count("mask_status")).order_by('total').reverse()
                )
    if(yesterday_query):
        for tr in yesterday_query:
            d = {}
            d['total'] = tr['total']
            d['u'] = User.objects.get(pid = tr['user_id'])
            yesterday_details.append(d)

    # ********************************************************************************
    comps_query = (
                    Student.objects.values("user__pid","user__email","user__first_name","user__last_name","dept__dept_name","violation_count")
                    .filter(dept__dept_name = "COMPS")
                    .order_by('violation_count').reverse()
                )

    it_query = (
                    Student.objects.values("user__pid","user__email","user__first_name","user__last_name","dept__dept_name","violation_count")
                    .filter(dept__dept_name = "IT")
                    .order_by('violation_count').reverse()
                )
    
    extc_query = (
                    Student.objects.values("user__pid","user__email","user__first_name","user__last_name","dept__dept_name","violation_count")
                    .filter(dept__dept_name = "EXTC")
                    .order_by('violation_count').reverse()
                )
    
    return render(request,'detect_mask/person_details.html',{'today_details':today_details,'user_query':user_query,'yesterday_details':yesterday_details,'comps_query':comps_query,'it_query':it_query,'extc_query':extc_query})


def mail(request,f,l,email,viol):
    body = f"Hello,\n{f} {l} \n\nThis is to inform you that your violation count is {viol}. \n Please, wear mask from the next time else authority will fine you\n\n Regards,\n SFIT Authority."
    send_mail(
            f" You are detected {viol}-times without Mask",
            body,
            settings.EMAIL_HOST_USER,
            [email],
            fail_silently = False
            )
    messages.success(request,"Email has been sent to the student !!")
    return redirect('detect_mask:display_details')

def smal(request):
    total_violation = (
                    MaskDetail.objects.values("user_id","user__email","user__first_name","user__last_name")
                    .annotate(total=Count("update_done"))
                    .order_by("total")
                    .reverse()
                )

    if total_violation:
        for tv in total_violation:
            if tv["total"] > 20:
                return mail(request,tv["user__first_name"],tv["user__last_name"],tv["user__email"],tv["total"])
    else:
        return redirect('detect_mask:display_details')
            
      
        

