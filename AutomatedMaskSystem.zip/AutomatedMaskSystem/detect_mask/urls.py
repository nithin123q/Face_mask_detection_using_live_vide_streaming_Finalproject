from django.contrib import admin
from django.urls import path
from detect_mask import views

app_name='detect_mask'

urlpatterns = [

    path('',views.main,name='main'),
    # path('test/',views.test,name='test'),
    path('video_feed', views.video_feed, name='video_feed'),
    path('display_details', views.display_details, name='display_details'),
    path('graph_details', views.graph_details, name='graph_details'),
    path('mail/<str:f>/<str:l>/<str:email>/<int:viol>', views.mail, name='mail'),  
    path('smal/', views.smal, name='smal'),  
]
