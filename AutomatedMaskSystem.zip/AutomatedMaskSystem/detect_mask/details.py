from detect_mask.models import User, Student, MaskDetail
from datetime import timedelta
from django.utils import timezone

def update_violation(request):
    today = datetime.today()
    user = User.objects.all()
    queryset = (
                    MaskDetail.objects.values("user_id","update_done")
                    .filter(
                    date_time__year=today.year,
                    date_time__month=today.month,
                    date_time__day=today.day,
                    update_done = False)
                    .annotate(total=Count("mask_status"))
                )
    if(queryset is not None):
        for row in queryset:
            pid = row['user_id']
            user = User.objects.get(pid = pid)
            new_violation = row['total'] + user.student.violation_count
            Student.objects.filter(user_id = user).update(violation_count = new_violation)
            MaskDetail.objects.filter(user_id = user).update(update_done=1)
            user = User.objects.all()
    return render(request,'detect_mask/person_details.html',{'user':user})









#
#<!-- <a class="btn btn-primary" id="btnid" href="{% url 'detect_mask:update_violation' %}">Update Vioalation</a> -->
