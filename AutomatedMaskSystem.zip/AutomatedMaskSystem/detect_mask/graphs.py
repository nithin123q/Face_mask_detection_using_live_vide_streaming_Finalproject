from django.db.models import Count
from django.core.mail import send_mail
import datetime
import matplotlib.pyplot as plt
import base64
from io import BytesIO
import pandas as pd
import numpy as np
import calendar

def get_graph():
    buffer = BytesIO()
    plt.savefig(buffer, formate='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    graph = base64.b64encode(image_png)
    graph = graph.decode('utf-8')
    buffer.close()
    return graph


def get_plot(x):
    plt.switch_backend("AGG")
    plt.title("Violation-count of everyday \n",fontsize = 16)    

    a = []
    b = []
    for x1 in x:
        a.append(x1["total"])
        date = x1["date_time__day"]
        month = calendar.month_name[x1["date_time__month"]]
        time = str(date) + "-" + month[0:3]
        b.append(time)

    plt.plot(b,a,"-b", label="violation count")
    plt.xlabel("Date-month",fontsize = 14)
    plt.ylabel("Violation count",fontsize = 14)
    plt.legend()    
    graph = get_graph()
    return graph
    
def get_pie(x):
    plt.switch_backend("AGG")
    plt.title("Percentage(%) of total violation-count of months \n",fontsize = 16)
    colors = ["blue","yellow"]
    
    first = x[0]["total"]
    second = x[1]["total"]

    first_month_name = calendar.month_name[x[0]["date_time__month"]]
    second_month_name = calendar.month_name[x[1]["date_time__month"]]

    labels = first_month_name,second_month_name

    plt.pie([first,second],explode=(0, 0.1), labels=labels,
                autopct='%1.1f%%', shadow=True, startangle=90,textprops={'fontsize': 16},colors=colors)

    plt.legend()
    graph = get_graph()
    return graph

def get_bar(x):
    plt.figure(figsize=(100,100))
    plt.switch_backend("AGG")  
        
    a = []
    b = []
    for x1 in x:
        a.append(x1["total"])
        b.append(x1["dept__dept_name"])

    plt.bar(b, a, color ='blue',width = 0.4)

    plt.title("Violation count per department\n",fontsize = 16)
    plt.xlabel("Department",fontsize = 14)
    plt.ylabel("Violation count",fontsize = 14)
    # plt.tight_layout()
    graph = get_graph()
    return graph